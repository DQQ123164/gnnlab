# SSG 二分类静态骨架数据集

SSG 来源于 POLAR（Posture-level Action Recognition）数据集，从原始 9 个姿态类别中筛选出 `sitting` 和 `standing` 两类。原始图像已经通过 OpenPose 转换为 BODY_25 JSON，每个 JSON 文件表示一个独立的单帧人体姿势。

## 类别与样本数

| 标签 | 类别 | 原始 train | 有效 train | test |
|---:|---|---:|---:|---:|
| 0 | sitting（坐姿） | 240 | 240 | 60 |
| 1 | standing（站姿） | 240 | 237 | 60 |
| **总计** | **2 类** | **480** | **477** | **120** |

`standing/train` 中有 3 个 JSON 没有检测到人体，预处理时会记录并跳过，因此最终训练数据包含 477 个样本。

## 原始目录

类别由文件所在目录决定：

- sitting  -> 标签 0
- standing -> 标签 1

```text
ssg/
|-- README.md
|-- sitting/
|   |-- train/*.json
|   `-- test/*.json
`-- standing/
    |-- train/*.json
    `-- test/*.json
```

## JSON 数据含义

预处理使用 OpenPose JSON 中的 `people[*].pose_keypoints_2d`。该字段按照下面的顺序保存 25 个 BODY_25 关节：

```text
[x, y, confidence, x, y, confidence, ...]
```

- `x、y`：关节在图像中的二维坐标。
- `confidence`：OpenPose 检测置信度。
- 面部、手部和三维关键点字段不作为本实验输入。
- 同一张图检测到多个人时，预处理器选择 BODY_25 关节置信度总和最高的人体。

## 坐标预处理

为了减少拍摄位置、画面尺寸和人体整体朝向对分类的影响，预处理器会：

1. 选择髋部中心作为坐标原点。
2. 将人体躯干方向旋转至竖直方向。
3. 使用有效肩部和髋部骨段长度的中位数进行尺度归一化。
4. 保留 OpenPose `confidence` 作为第三个输入通道。
5. 对无效或缺失关节写入零值。

该处理保留四肢相对于躯干的伸展关系，输出单个样本的形状为 `(25, 3)`。
